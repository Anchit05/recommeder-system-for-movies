package project;


import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFactory;
import com.hp.hpl.jena.query.ResultSetRewindable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

public class count_Starring {
    
    public static void main(String args[]) throws FileNotFoundException, IOException {        
        String service = "http://localhost:8890/sparql";
        System.setProperty("entityExpansionLimit", "1000000");
        String x, y = null;
        int i = 1;
        FileInputStream fstream = new FileInputStream("/home/ankit/NetBeansProjects/project_6th_sem/src/project/DBpedia_movieLens");
        // Get the object of DataInputStream
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String strLine;
        //Read File Line By Line
        int l = 0;
        while ((strLine = br.readLine()) != null) {
            // Print the content on the console
            System.out.print("\n");
            System.out.print(strLine + " ");
            l++;
            String sparqlQueryString1
                    = "PREFIX on:<http://dbpedia.org/ontology/>" + "\n"
                    + "PREFIX dbprop:<http://dbpedia.org/property/>" + "\n"
                    + "PREFIX dcterms: <http://purl.org/dc/terms/>" + "\n"
                    + "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" + "\n"
                    + "PREFIX skos: <http://www.w3.org/2004/02/skos/core#>"+"\n"
                    + "SELECT DISTINCT  ?o FROM <http://dbpedia.org>  WHERE {<"+strLine+"> dcterms:subject ?o}";
//+ "SELECT DISTINCT  ?name ?o FROM <http://dbpedia.org>  WHERE {<" + strLine + "> dbprop:starring  ?o.?o rdfs:label ?name. FILTER (langMatches (LANG(?name), \"en\"))}";             
//System.out.println(sparqlQueryString1);  
            
            QueryExecution qexec = QueryExecutionFactory.sparqlService(service, sparqlQueryString1);
            try {
                ResultSet results = qexec.execSelect();
                for (; results.hasNext();) {
                    QuerySolution soln = results.nextSolution();
                    //  y=soln.get("o").toString();
                    x = soln.get("o").toString();
                 //   System.out.print("\n" + x + "\n");
                    //System.out.print(x + "\n");
                   // if(x==null){}
                   // x = soln.get("name").toString();
                    sparql(x);
                     System.out.print(x + " ");
                     
                }
                //System.out.println("ankit  " + l);

//                     score = alpha * ((Math.log(M))/flag);
//         System.out.print("    score"+score);  
//        
            } finally {
                qexec.close();
                //    long endTime = System.currentTimeMillis();
            }
         //  System.out.print("\n--------------------------dcterms+Skos broader over for" + i + "------------------------\n");
            i++;
      //System.out.println("Total elapsed time in execution of Dcterms Property is :"+ (endTime-startTime)/1000+"seconds");

            //bw.write("\n--------------------------Dcterms properties over for this------------------------\n");
        }

//bw.close();
    }

    private static void sparql(String x) {
        long i=1;
        System.setProperty("entityExpansionLimit", "1000000");
        double score, M = 77794;
        String y;
        int numberOfRows = 0;
        String sparqlQueryString
                = "PREFIX on:<http://dbpedia.org/ontology/>" + "\n"
                + "PREFIX dbprop:<http://dbpedia.org/property/>" + "\n"
                + "PREFIX dcterms: <http://purl.org/dc/terms/>" + "\n"
                   + "PREFIX skos: <http://www.w3.org/2004/02/skos/core#>"+"\n"
                + "SELECT DISTINCT ?s FROM <http://dbpedia.org>  WHERE {<"+x+"> skos:broader ?s}";
        QueryExecution qe = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", sparqlQueryString);
    //   System.out.println(sparqlQueryString);
  
        try {     //System.out.print("nidhi");
            ResultSet results = qe.execSelect();
//                 ResultSetRewindable rsrw;
//                   rsrw = ResultSetFactory.copyResults(results);
//                              numberOfRows = rsrw.size();
                               // System.out.print("count_of_s " + numberOfRows + "\n");
          while (results.hasNext()) {
                 QuerySolution soln = results.nextSolution();
                 y=soln.get("s").toString();
//                 rsrw = ResultSetFactory.copyResults(results);
//                numberOfRows = rsrw.size();
                 //  y=soln.get("o").toString();
                //y = soln.get("s").toString();
                //   numberOfRows=numberOfRows+1;
                //System.out.print("count_of_s   " + flag + "\n"+ y.toString());
               System.out.print(y + " ");
                 i++;
                 
           }
//           System.out.print("count_of_s " + i+ "\n");
//           System.out.println("Math.log(M)/Math.log(10)" + Math.log(M)/Math.log(10));
//           System.out.println("((Math.log(M)/Math.log(10))/flag)" + ((Math.log(M)/Math.log(10))/(i)));
         //  score = 1 * ((Math.log(M) / Math.log(10)) /(i));
         //  System.out.print("\n   " + score);
        } finally {}
    }}
