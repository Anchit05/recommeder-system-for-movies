#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
using namespace std;
int main()
{
	ifstream f;
	f.open ( "u.user");
	int a,b;
	string c,d;
	string str;
	map < string,int> pin;
	map<string,int>::iterator it;
	int u = 1,u1 = 1;
	while ( !f.eof() ) {
		f >> a;
		f >> b;
		f >> c;
		f >> d;
		f >> str;
//		cout << str << endl;
		if ( pin.count ( str ) == 0 ) {
			pin.insert ( pair<string,int>(str,u1));
			u1++;
		}
	}
	cout << pin.size() << endl;
	f.close();
	for ( it = pin.begin(); it != pin.end(); it++ ) {
		cout << (*it).first << endl;
	}
	/*ifstream f1;
	f1.open( "u.user");
	while ( !f1.eof() ) {
		f1 >> a;
		f1 >> b;
		f1 >> c;
		f1 >> d;
		f1 >> str;

		if ( pin.count ( str ) > 0 ) {
			u = pin[str];
		}else {
			cout << str << endl;
		}
		if ( b >= 0 && b <= 20 ) {
			u1 = 1;
		}else if ( b > 20 && b <= 30 ) {
			u1 = 2;
		}else if ( b > 30 && b <= 40 ) {
			u1 = 3;
		}else if ( b > 40 && b <= 50 ) {
			u1 = 4;
		}else if ( b > 50 && b <= 60 ) {
			u1 = 5;
		}else if ( b > 60 && b <= 100 ) {
			u1 = 6;
		}
		cout << a << " "<<u1 << " "<<c << " "<<d << " "<<u<< endl; 
	}
	f1.close();*/
		
	return 0;
}


